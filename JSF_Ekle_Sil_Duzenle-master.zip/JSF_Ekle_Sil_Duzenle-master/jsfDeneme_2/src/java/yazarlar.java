
public class yazarlar {

    String adi, alani;
    int ID;
    boolean guncellenebilirlik;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public boolean isGuncellenebilirlik() {
        return guncellenebilirlik;
    }

    public void setGuncellenebilirlik(boolean guncellenebilirlik) {
        this.guncellenebilirlik = guncellenebilirlik;
    }

    public String getAdi() {
        return adi;
    }

    public void setAdi(String adi) {
        this.adi = adi;
    }

    public String getAlani() {
        return alani;
    }

    public void setAlani(String alani) {
        this.alani = alani;
    }
}
